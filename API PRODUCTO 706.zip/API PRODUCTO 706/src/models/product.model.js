import db from '../config/database.js';


export class ProductModel{

    static async findAll() {
    const [rows] = await db.query('SELECT * FROM productos');
    return rows;
  }

  static async findById(id) {
    const [rows] = await db.query('SELECT * FROM productos WHERE id = ?', [id]);
    return rows[0] || null;
  }

  static async create({ nombre, precio, stock }) {
    const [result] = await db.query(
      'INSERT INTO productos (nombre, precio, stock) VALUES (?, ?, ?)',
      [nombre, precio, stock]
    );
    return { id: result.insertId, nombre, precio, stock };
  }

  static async update(id, { nombre, precio, stock }) {
    const [result] = await db.query(
      'UPDATE productos SET nombre = ?, precio = ?, stock = ? WHERE id = ?',
      [nombre, precio, stock, id]
    );
    return result.affectedRows > 0;
  }

  static async delete(id) {
    const [result] = await db.query('DELETE FROM productos WHERE id = ?', [id]);
    return result.affectedRows > 0;
  }


}